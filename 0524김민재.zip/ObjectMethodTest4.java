/*
 * 작성일 : 2024년 5월 24일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: object 클래스의 toString()메소드 
 * 객체를 문자열로 표현할 때 사용하는 것이다. 
 */

public class ObjectMethodTest4 {
	
	class box11{
		int width, height, depth;
		public box11(int w, int h, int d){
			width = w;
			height = h;
			depth = d;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = new String("처음 시작하는 자바");
		String s2 = new String("처음 시작하는 자바");
		System.out.println(s1.equals(s2) ? "s1과 s2는 같다" : "s1과 s2는 다르다.");
		System.out.println(s1==s2 ? "s1과 s2는 같다" : "s1과 s2는 다르다.");

	}
}

