/*
 * 작성일 : 2024년 5월 24일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 메서드 오버라이딩 1
 */
class ST1a{
	public int x = 500;
	public int y = 1000;
}

class ST1b extends ST1a{
	public String x = "처음 시작하는 자바";
	public String xx = x + super.x;
	public String yy = y + " " + super.y;
	// x, xx, yy, 상속받은 y, 상위 클래스 x는 없다.
}
public class SuperTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ST1b stb = new ST1b();
		System.out.println("x값 : " + stb.x);
		System.out.println("y값 : " + stb.y);
		System.out.println("xx값 : " + stb.xx);
		System.out.println("yy값 : " + stb.yy);
		
	}

}
