/*
 * 작성일 : 2024년 5월 24일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: object 클래스의 toString()메소드 
 * 객체를 문자열로 표현할 때 사용하는 것이다. 
 */
class AAA1{
	public int a = 10;
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "AAA1클래스 객체 속성 a의 값은 : " + a;
	}
	
}
public class ObjectMethodTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AAA1 a1 = new AAA1();
		System.out.println(a1.toString());
		System.out.println(a1);
	}
}

