/*
 * 작성일 : 2024년 5월 24일  
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 메서드 오버라이딩 1
 */
class OT1a3{
	public void show(String str) {
		System.out.println("상위 클래스 메소드 show(String str) 수행 : " + str);
	}
}
class OT1b3 extends OT1a3{
	@Override //오버라이드 하고 있는지 주석, 검사를 해줌. 
	public void show(String str) {
		// TODO Auto-generated method stub
		//상위 클래스로 접근할 때 사용.
		//super.show(str);
		System.out.println("하위 클래스 메소드 show(String str) 수행 : " + str);
	}
}
public class OverridingTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OT1b3 otb = new OT1b3();
		otb.show("오늘은 금요일");
	}

}
