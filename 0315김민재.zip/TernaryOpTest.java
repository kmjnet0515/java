/*
 * 작성일 : 2024년 3월 15일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 삼항연산자 
 */
import java.util.Scanner;
public class TernaryOpTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		System.out.print("수를 입력하세요.");
		int a = stdIn.nextInt();
		boolean result;
		result = (a % 2 == 0) ? true : false;
		System.out.println(a + "은 짝수입니까?\n" + result);
		String result2 = (a % 2 == 0) ? "짝수" : "홀수";
		System.out.printf("%d는 %s입니다.",a , result2);
	
	}

}
