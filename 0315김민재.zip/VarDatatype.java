/*
 * 작성일 : 2024년 3월 15일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 변수와 자료형 
 */
public class VarDatatype {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int MAX = 100;
		final double PI = 3.14;
		//상수는 한 번 값이 결정되면 변할 수 없다. 
		//PI = 3.141592;
		int r = 5; //정수 
		double pi = 3.141592;//실수 변수 
		String name = "김민재"; // 문자열 
		char blood = 'A'; //문자 
		System.out.println("상수 : " + PI + "\n변수 : " + pi);
		
		//원의 넓이 계산하여 출력
		double circleArea = pi*r*r;
		System.out.printf("반지름이 %d인 원의 넓이는 %.2f입니다.\n",r, circleArea);
	}

}
