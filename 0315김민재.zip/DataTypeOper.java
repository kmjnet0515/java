/*
 * 작성일 : 2024년 3월 15일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 연산과 자료형
 * 		  두 개의 정수를 입력 받아 평균을 계산하는 프로그램.
 */
import java.util.Scanner;
public class DataTypeOper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1 두 정수를 입력받는다.
		Scanner number = new Scanner(System.in);
		//2. 평균을 계산한다.
		System.out.print("첫 번째 정수 입력 : ");
		int a = number.nextInt();
		System.out.print("두 번째 정수 입력 : ");
		int b = number.nextInt();
		//3. 평균을 출력한다.
		double avg = (a + b)/2.0;
		System.out.printf("%d, %d의 평균은 %g입니다.", a, b, avg);
	}

}
