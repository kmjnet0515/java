/*
 * 작성일 : 2024 5월 10일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 클래스 모음 
 */
class Box6{
	int width, height, depth;
	double dwidth, dheight, ddepth;
	public Box6(int w, int h, int d) {
		width = w;
		height = h;
		depth = d;
	}
	public Box6(double w, double h, double d) {
		dwidth = w;
		dheight = h;
		ddepth = d;
	}
}
public class BoxOverloading02 {
	
	public static void main(String[] args) {
		Box6 box = new Box6(10,20,30);
		int vol = box.width * box.height * box.depth;
		System.out.println("박스의 부피(정수 매개 변수) : " + vol);
		Box6 box2 = new Box6(10,20,10.5);
		double dvol = box2.dwidth * box2.dheight * box2.ddepth;
		System.out.println("박스의 부피(실수 매개 변수) : " + dvol);
	}

}
