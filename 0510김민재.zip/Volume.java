/*
 * 작성일 : 2024 5월 10일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 클래스 모음 
 */

import java.util.Scanner;

class Box{
	int width, height, depth; //멤버변수, 객체 변수		클래스 전역에서 사용 가능 
	//매개변수가 3개인 생성자
	public Box(int width, int height, int depth) {
		this.width = width; //매개변수 값을 객체 변수에 대입 
		this.height = height;
		this.depth = depth;
	}
	//생성자 오버로딩 
	public Box() {
		width = 0;
		height = 0;
		depth = 0;
	}
	public int Vol(){
		return width * height * depth;
	}
}
public class Volume {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		System.out.print("가로 입력 : ");
		int width = stdIn.nextInt();
		System.out.print("높이 입력 : ");
		int height = stdIn.nextInt();
		System.out.print("깊이 입력 : ");
		int depth = stdIn.nextInt();
		Box box = new Box(width, height, depth);
		System.out.println("box의 부피는 : " + box.Vol());
		Box box2 = new Box();
		System.out.println("box2의 부피는 : " + box2.Vol());
	}

}
