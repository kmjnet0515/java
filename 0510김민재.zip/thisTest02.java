/*
 * 작성일 : 2024 5월 10일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 클래스 모음 
 */
class Box2{
	int width, height, depth;
	public Box2(int width, int height, int depth) {
		this.width = width;
		this.height = height;
		this.depth = depth;
	}

}
public class thisTest02{
	
	public static void main(String[] args) {
		Box2 box = new Box2(1,2,3);
	}

}
