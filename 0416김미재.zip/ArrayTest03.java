/*
 * 작성일 : 2024년 4월 16일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 1차원 배열에 정수 값을 저장하여 생성하시오.
 * 사용자로부터 정수를 입력받아 그 정수가 어디에 몇 개 있는지 출력하시오.
 * 입력한 값이 배열에 없다면 "입력한 값이 없습니다."를 출력하시오.
 * 1. 배열에 값 저장.
 * 2. 찾고 싶은 정수를 입력 받기
 * 3. 배열의 길이까지 반복하면서
 * 3.1 입력받은 수와 배열 각 번지에 저장된 값이 같은지 비교
 * 3.1.1 같다면 count 증가
 * 3.1.2 현재 위치 출력
 * 4. count가 0이면 일치한다 출력
 * 5. 아니면 총 개수 출
 */
import java.util.Scanner;
public class ArrayTest03 extends ArrayTest01{
	//중복된 값을 허용하지 않는 배열 입력 
	public static void inputArr2(int[] arr) {
		Scanner stdIn2 = new Scanner(System.in);
		first: for(int i = 0; i<arr.length;) {
			System.out.print("값을 입력하세요. : ");
			arr[i] = stdIn2.nextInt();
			for(int k = i - 1; k >= 0; k--) {
				if(arr[i] == arr[k]) {
					System.out.println("다시 입력하세요. 값이 중복되었습니다. ");
					continue first;
				}
			}
			i++;
		}
		printArr(arr);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		int[] arr = new int[10];
		inputArr(arr);
		System.out.print("찾을 숫자를 입력하세요. ");
		int result = findArr(arr, stdIn.nextInt());
		if(result == 0) System.out.println("입력한 값이 없습니다. ");
		else System.out.println( result + "개 있습니다.");
		int[] arr2 = new int[10];
		inputArr2(arr2);
	}

}
