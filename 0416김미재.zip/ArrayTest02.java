/*
 * 작성일 : 2024년 4월 16일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 배열에 저장된 값 중 최대값과 최솟값을 출력하시오. 
 * 첫번째 값을 기준으로 비교하여 1번지부터 배열의 끝까지 비교후 최댓값을 출력한다.
 * 최대는 max, 최소는 min에 저장
 */
public class ArrayTest02 extends ArrayTest01{
	public static int maxArr(int[] arr) {
		int max = arr[0];
		for(int i = 1; i<arr.length; i++) {
			if(arr[i] > max) {
				max = arr[i];
			}
		}
		return max;
	}
	public static int minArr(int[] arr) {
		int min = arr[0];
		for(int i = 1; i<arr.length; i++) {
			if(arr[i] < min) {
				min = arr[i];
			}
		}
		return min;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = new int[10];
		makeRanArr(arr);
		printArr(arr);
		System.out.println("최댓값은 : " + maxArr(arr) + "입니다.");
		System.out.println("최솟값은 : " + minArr(arr) + "입니다.");
	}

}
