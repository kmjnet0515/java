/*
 * 작성일 : 2024년 4월 16일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 1차원 배열을 생성하고, 묵시적 초기값을 출력한다. 
 */
import java.util.Scanner;
import java.util.Random;
public class ArrayTest01 {
	public static int sumArr(int[] arr) {
		int sum = 0;
		for(int i : arr) {
			sum += i;
		}
		return sum;
	}
	public static double avgArr(int[] arr) {
		return sumArr(arr)/(double)arr.length;
	}
	public static void printArr(int[] arr) {
		for(int i : arr) {
			System.out.print(i + " ");
		}
	}
	public static void reverseArr(int[] arr) {
		for(int i = 0; i<arr.length/2; i++) {
			int temp = arr[i];
			arr[i] = arr[arr.length - i - 1];
			arr[arr.length - i - 1] = temp;
		}
	}
	public static void inputArr(int[] arr) {
		Scanner stdIn = new Scanner(System.in);
		System.out.print("입력할 값은 "+ arr.length + " 개입니다. 값을 입력하세요. : ");
		for(int i = 0; i<arr.length; i++) {
			arr[i] = stdIn.nextInt();
		}
	}
	public static void sortArr(int[] arr) {
		for(int i = 0; i < arr.length; i++) {
			for(int k = i ; k < arr.length; k++) {
				if(arr[i] > arr[k]) {
					int temp = arr[k];
					arr[k] = arr[i];
					arr[i] = temp;
				}
			}
		}
		System.out.print("정렬 결과 : ");
		printArr(arr);
	}
	public static int findArr(int[] arr, int k) {
		int count = 0;
		for(int i = 0; i<arr.length; i++) {
			if(arr[i] == k) {
				System.out.println(i +"인덱스에 " + k +"가 있습니다.");
				count ++;
			}
		}
		return count;
	}
	public static void makeRanArr(int[] arr) {
		Random ran = new Random();
		for(int i = 0; i<arr.length; i++) {
			arr[i] = ran.nextInt()%10;
			if(arr[i] < 0) arr[i] *= -1;
		}
	}
	public static void main(String[] args) {
		Scanner stdIn2 = new Scanner(System.in);
		// TODO Auto-generated method stub
		//비어있는 배열 생
		int[] arr = new int[10];
		printArr(arr);
		//출력
		int[] arr2 = {1,2,3,4,5};
		for(int i : arr2) {
			System.out.println(i + " ");
		}
		//거꾸로 바꾸기 
		reverseArr(arr2);
		//출력 
		printArr(arr2);
		System.out.println(sumArr(arr2));
		System.out.println(avgArr(arr2));
		int[] arr3 = new int[5];
		inputArr(arr3);
		printArr(arr3);
		sortArr(arr3);
		int[] arr4 = new int[10];
		makeRanArr(arr4);
		printArr(arr4);
		System.out.print("찾을 숫자를 입력하세요. ");
		findArr(arr4, stdIn2.nextInt());
	}
}

