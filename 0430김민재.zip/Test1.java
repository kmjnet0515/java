/*
 * 작성일 : 2024년 4월 30일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 메인 메소드가 있는 클래스 
 * 클래스로부터 객체 생성 
 */
public class Test1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PlusMinus cal = new PlusMinus();
		System.out.println(cal.Add(1,5));
		MultiDiv cal2 = new MultiDiv();
		System.out.println(cal2.Add(1, 7));
		System.out.println(cal2.Mul(2, 50));
		
	}
}
