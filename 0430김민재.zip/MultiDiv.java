/*
 * 작성일 : 2024년 4월 30일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: plus minus 기능과 곱 나누기 기능을 추가한 클래슷 ㅐㅇ성 
 */
public class MultiDiv extends PlusMinus{
	public int Mul(int num1, int num2) {
		return num1 * num2;
	}
	public int Div(int num1, int num2) {
		if(num2 == 0) {
			return 0;
		}
		return num1 / num2;
	}
}
