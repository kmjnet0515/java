/*
 * 작성일 : 2024년 4월 30일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: plus minus 클래스 생성 더하기 빼기 기능 만들기 
 */
public class PlusMinus {
	public int Add(int num1, int num2) {
		return num1 + num2;
	}
	public int Sub(int num1, int num2) {
		return num1 - num2;
	}
}
