/*
 * 작성일 : 2024년 3월 8
 * 작성자 : 컴퓨터공학부 202395006 김민
 * 설명	: 첫 번째 자바 프로그
 */
public class First {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("hello world\n김민재입니다.");
		System.out.println("반갑습니다." + "첫 번째 자바 프로그램입니다.");
	}

}
