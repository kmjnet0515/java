/*
 * 작성일 : 2024년 4월 12일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 점수를 입력 받아 합계와 평균을  출력하시오. 
 * 음수가 입력되면 점수 입력이 종료됩니다.
 * 100점 이상의 점수는 계산에 포함되지 않습니다.  
 * 문제붆석 : 
 * 계속 해서 점수를 입력받는다. 무한반복 합계 구하기
 * 
 */

import java.util.Scanner;
public class ContinueBreak1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		int sum = 0, i = 0;
		while(true) {
			System.out.println("점수 입력 : ");
			int num = stdIn.nextInt();
			if(num < 0)break;
			if(num > 100)continue;
			sum += num;
			i++;
		}
		System.out.println("총합은 : " + sum + "\n평균은 : " + (double)sum/i);
	}

}
