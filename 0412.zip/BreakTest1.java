/*
 * 작성일 : 2024년 4월 12일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 1부터 10까지 합을 출력하시오.
 * 문제분석 : 초기값 1부터 10까지 1씩 증가하면서 sum에 num을 더하기.
 * 알고리즘 :
 * 1. num = 1, sum = 0 선언 초기화 
 * 2. 입력받기
 * 3. 무한반복하면서 
 * 3.1. num과 입력받은 수가 같다면
 * 3.1.1 반복문 탈출 
 * 3.2 sum에 num++더하기
 * 4. 출력  
 */
import java.util.Scanner;
public class BreakTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner stdIn = new Scanner(System.in);
		int num = 1, sum = 0;
		System.out.print("수를 입력하세요. : ");
		int input = stdIn.nextInt();
		while(true) {
			if(num > input)break;
			sum += num++;
		}
	}
}
