/*
 * 작성일 : 2024년 4월 12일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: continue 
 */
import java.util.Scanner;

public class ContinueTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		System.out.println("원하는 정수 입력 : ");
		int num = stdIn.nextInt();
		int i,sum=0;
		for(i = 1; i<= num ; i++) {
			if(i %2 == 1) continue;
			sum += 1;
		}
		System.out.println("1부터 " +num + "까지 합 = " + sum);
	}

}
