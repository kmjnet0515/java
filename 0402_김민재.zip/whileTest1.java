/*
 * 작성일 : 2024년 4월 2일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 1부터 10까지 합을 출력하시오.
 * 문제분석 : 1+2+3+4+5+6+7+8+9+10 
 * 			1부터(초기값)
 * 			10까지(조건식)
 * 			1씩 증가(증감식)
 * 			하면서 합계를 계산한다.

 * 알고리즘 : 
 * 1. number 변수에 초기값 1 
 * 2. sum 변수에 초기값 0 
 * 3. 반복하면서 
 * 3.1 sum에 number 더하기 
 * 3.2 number에 1더하기 
 * 4. sum변수 출력하기 
 */
public class whileTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number = 1, sum = 0;
		while(number <= 10) {
			sum += number;
			number += 1;
		}
		System.out.println("합계는 " + sum +"입니다.");
	}

}
