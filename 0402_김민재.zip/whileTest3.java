/*
 * 작성일 : 2024년 4월 2일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 정수를 입력 받아 정수의 팩토리얼 값을 출력하시오. 
 * 문제분석 : 입력받은 수를 1씩 감소하며 1이 되기 전까지 곱한 수를 출력한다. 

 * 알고리즘 : 
 * 1. number에 수를 입력받기. 
 * 2. number2 변수 1로 선언, 초기화 
 * 3. number2가 1보다 클 때까지 반복  
 * 3.1. number와 number2의 곱을 number2에 저
 * 3.2. number2에 1 빼기  
 * 4. 출력 
 */
import java.util.Scanner;
public class whileTest3 {
	public static int factorial(int num) {
		if(num == 1) {
			return 1;
		}
		return num * factorial(num - 1);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		System.out.print("수를 입력하세요. : ");
		int number = stdIn.nextInt(), number2 = 1;
		System.out.print(number +"! = ");
		while(number > 1) {
			System.out.print(number + ((number != 2) ? " * ": " * 1 => "));
			number2 *= number--;
		}
		System.out.println(number2);
		System.out.println(factorial(10));
	}
}
