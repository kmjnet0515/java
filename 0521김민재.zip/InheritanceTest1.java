/*
 * 작성일 : 2024년 5월 21일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명 : 상속과 한정자 
 */
class A{
	public int aa = 1;//멤버 변수. 모두 접근 가능 
	
}
//A클래스를 상속받음. 
class B extends A{
	private int bb = 2;//멤버 변수. B클래스에서만 접근 가능. 
	public int bb() {//메소드. 모두 접근 가능. 
		return bb; //이 메소드를 이요하여 외부에서는 접근이 불가능한 bb를 사용할 수 있다. 
	}
	//이 클래스에는 aa, bb, bb()가 있다.
}
class C extends B{
	//이 클래스에는 aa, bb, bb()가 있다. 
	int cc = 3;//한정자가 없음. 같은 패키지 내에서만 접근이 가능함. 
}
public class InheritanceTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C objC = new C();
		System.out.println("cc : " + objC.cc);
		System.out.println("bb : " + objC.bb());
		System.out.println("aa : " + objC.aa);
	}

}
