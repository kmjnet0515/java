/*
 * 작성일 : 2024년 5월 21일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명 : 상속과 우선순위 
 */

public class InheritanceTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C objC = new C();
		System.out.println("cc : " + objC.cc);
		System.out.println("bb : " + objC.bb());
		System.out.println("aa : " + objC.aa);
	}

}

