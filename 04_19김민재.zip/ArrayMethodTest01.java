/*
 * 작성일 : 2024년 4월 19일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: Arrays 클래스와 system 클래스에서 제공하는 메소드 연
 */
import java.util.Arrays;
import java.util.Scanner;
public class ArrayMethodTest01 extends ArrayTest01{
	public static void printArr2(int arr[]) {
		//배열의 내용을 문자열의 형태로 반환해서 배열의 내용을 쉽게 확인하고 디버깅하는데 사용 
		System.out.println(Arrays.toString(arr));
	}
	public static int findArr2(int arr[], int find) {
		int i;
		for(i = 0; i<arr.length; i++) {
			if(arr[i] == find) {
				break;
			}
		}
		return i;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1[] = new int[10];
		makeRanArr(num1);
		printArr2(num1);
		
		//인덱스 3부터 4까지 33으로 바꿈 
		Arrays.fill(num1, 3,5,33);
		System.out.println("fill()메소드 실행 후 ");
		printArr2(num1);
		
		//정렬
		Arrays.sort(num1);
		printArr2(num1);
		
		//원소 찾기 -> 인덱스 반환 조건(배열이 정렬되어있어야함) 
		System.out.println("33은 배열의 " + Arrays.binarySearch(num1,33) + "번째 요소");
		System.out.println("33은 배열의 " + findArr2(num1, 33) + "번째 요소");
		
		
		int num2[] = {5,4,3,2,1};
		System.out.println("num2의 배열 : " + Arrays.toString(num2));
		
		System.out.println("두 배열은 같은가? " + Arrays.equals(num1, num2));
		
		int[] num3 = new int[5];
		
		//배열에 값 복사하는 메소드
		//num2배열의 0번지부터 num3의 0번지위치로 3개 복사된다.
		//남은 공간은 디폴트 값 0으로 복사된다.
		System.arraycopy(num2, 0, num3, 2, 3);
		System.out.println("복사된 배열 num3 : " + Arrays.toString(num3));
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
