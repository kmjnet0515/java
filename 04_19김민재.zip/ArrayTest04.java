/*
 * 작성일 : 2024년 4월 19일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 배열의 복사
 * 배열의 복사는 값이 복사되는 것이 아닌 주소를 복사한다.
 * 배열을 복사하면 같은 주소를 가리키게 된다.
 */
import java.util.Arrays;
import java.util.Scanner;
public class ArrayTest04 extends ArrayTest01{
	public static void printArr2(int arr[]) {
		//배열의 내용을 문자열의 형태로 반환해서 배열의 내용을 쉽게 확인하고 디버깅하는데 사용 
		System.out.println(Arrays.toString(arr));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1[] = {10,20,30};
		int num2[] = {40,50,60};
		/*
		printArr(num1);
		printArr(num2);
		*/
		printArr2(num1);
		printArr2(num2);
		//배열 복사 같은 주소를 가리킴(주소가 복사됨)
		num2 = num1;
		System.out.println("배열 복사 후");
		printArr2(num1);
		printArr2(num2);
		num1[2] = 200;
		System.out.println("2번지 값 변경");
		printArr2(num1);
		printArr2(num2);
		int num3[] = {100,200,300}, num4[] = {400,500,600};
		System.out.println("배열 원본 값");
		printArr2(num3);
		printArr2(num4);
		for(int i = 0; i<num3.length; i++) {
			num4[i] = num3[i]; //배열의 값을 각각 복사
		}
		printArr2(num3);
		printArr2(num4);
		System.out.println("각각 복사 후 값 변경");
		num3[2] = 1000;
		printArr2(num3);
		printArr2(num4);
	}

}
