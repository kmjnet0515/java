/*
 * 작성일 : 2024년 3월 12일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: scanner 사용 
 */
import java.util.Scanner;

public class KeyInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		
		System.out.println("당신의 이름을 입력하세요 : ");
		
		String name = stdIn.next();
		
		System.out.println("안녕하세요. " + name + "님 반갑습니다.");
	}

}
