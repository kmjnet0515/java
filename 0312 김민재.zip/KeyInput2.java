/*
 * 작성일 : 2024년 3월 12일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: scanner 사용 
 */
import java.util.Scanner;
public class KeyInput2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		
		//이름, 나이, 몸무게 한 번에 입력 받기 => 스페이스바로 구분. 
		System.out.print("이름과 나이, 몸무게를 입력하세요.(스페이스 바로 구분)");
		
		//이름(문자열)을 입력 받아 변수에 저장. 
		//문자열은 next()
		String name = stdIn.next();
		//나이(정수)를 입력 받아 변수에 저장. 
		//정수는 nextInt()
		int age = stdIn.nextInt();
		//몸무게(실수)를 입력 받아 변수에 저장. 
		//실수는 nextDouble()
		double weight = stdIn.nextDouble();
		
		//출력
		System.out.print(name + "님의 나이는 " + age +"이고, ");
		System.out.println("몸무게는 " + weight +"kg입니다.");
		
		Scanner stdIn2 = new Scanner(System.in);
		int a = 0;
		while(stdIn2.hasNext()) {
			System.out.println(stdIn2.next());
			a += 1;
			if(a == 10)break;
		}
				
	}

}
