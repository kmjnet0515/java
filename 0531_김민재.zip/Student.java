/*
 * 작성일 : 2024년 5월 31일 
 * 작성자 : 컴퓨터공학부 202395006 김민재
 * 
 * 문제: student_class 클래스를 작성하세요.
 * 이 클래스는 다음과 같은 속성을 가집니다.
 * private String name 
 * private int studentId 
 * private double grade
 * 
 * 다음 요구 사항을 만족하는 생성자를 작성하세요.
 * 기본 생성자: name을 "홍길동", studentId를 0, grade를 0.0으로 초기화합니다
 *  매개변수가있는 생성자: 이름, 학생 ID, 학점을 입력받아 초기화합니다.
 * 메소드: printstudentInfo(): 학생의 정보를 출력합니다.
 * student 클래스
 * main 메소드 : student_class 객체를 두 개 생성하고, 각각의 정보를 출력합니다. 
 * [ 출력결과]
 * Name : 홍길동 , Student ID : 0, 학점 0.0
 * nmae : 김지연, Student ID : 202295000, 학점  3.9
 */
class Student_class{
	private String name;
	private int studentId;
	private double grade;
	//묵시적 생성자 
	public Student_class(){
		this.name = "홍길동";
		this.studentId = 0;
		this.grade = 0.0;
	}
	//생성자 오버로딩 
	public Student_class(String name, int studentId, double grade) {
		this.name = name;
		this.studentId = studentId;
		this.grade = grade;
	}	
	//값 출력 메소드 
	public void printStudentInfo() {
		System.out.println("Name : " + name + ", Sutdent ID : " + studentId + ", 학점 : " + grade);
	}
}
public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student_class st1 = new Student_class();
		st1.printStudentInfo();
		Student_class st2 = new Student_class("김민재", 202395006, 4.5);
		st2.printStudentInfo();
	}

}
