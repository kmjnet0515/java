/*
 * 작성일 : 2024년 4월 30일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 2차원 배열을 생성하고, 랜덤수를 배열의 초기값으로 설정합니다. 
 */
import java.util.Arrays;
import java.util.Random;
public class MultiArrayTest01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] num = new int[4][4];
		int[] sumOfNum = new int[num.length];
		Random r = new Random();
		for(int i = 0; i< num.length; i++) {
			int sum = 0;
			for(int k = 0; k<num[0].length; k++) {
				num[i][k] = r.nextInt(1,10);
				sum += num[i][k];
			}
			System.out.print(Arrays.toString(num[i]) + " -> ");
			System.out.println(sum);
			sumOfNum[i] = sum;
		}
		//2차원 배열을 문자 형태로 출력 
		System.out.println(Arrays.deepToString(num));
		System.out.println(Arrays.toString(sumOfNum));
	}

}
