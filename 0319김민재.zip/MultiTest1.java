/*
 * 작성일 : 2024년 3월 19일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 단순 if문 실습. 
 * 		  하나의 정수를 입력 받아 음수인지 확인하는 프로그램. 
 * 
 * 문제분석 : 음수는 0보다 작은 수이다. 
 * 			정수를 입력 받아 0보다 작은지 비교, 판단 
 * 			양수는 0보다 작은 수이다. 
 * 			정수를 입력 받아 0보다 큰지 비교, 판단 
 * 			0은 0이다.
 * 알고리즘 : 1. 정수를 입력받는다.
 * 			2. 입력받은 정수가 0보다 작은지 판단한다.
 * 				2-1. 음수출력 
 * 			3. 아니고, 입력받은 정수가 0보다 큰지 판단한다.
 * 				3-1. 양수출력  
 * 			4. 아니면
 * 				4-1. 0입니다.
 */
import java.util.Scanner;
public class MultiTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		System.out.print("수를 입력하세요. : ");
		int num = stdIn.nextInt();
		if(num > 0) {
			System.out.println(num + "(은)는 양수입니다.");
		}
		else if(num < 0) {
			System.out.println(num + "(은)는 음수입니다.");
		}
		else {
			System.out.println(num + "은 양수도 음수도 아닙니다.");
		}
	}

}
