/*
 * 작성일 : 2024년 3월 22일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 
 * 조건식 연습
 * 월을 입력받아 해당 계절을 출력하시오.
 * 3,4,5월 -> 봄 
 * 6,7,8월 -> 여름 
 * 9,10,11 -> 가을 
 * 12,1,2 -> 겨울 
 * 
 * 문제분석 : 입력 받아야할 값은
 * 1,2,3,4,5,6,7,8,9,10,11,12이다.
 * 0이나 13을 입력하면 ? -> 해당 월은 없습니다. 출력 
 * 내포된 if
 */
import java.util.Scanner;
public class ComConditionTest1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("월 : ");
		Scanner stdIn = new Scanner(System.in);
		int i = stdIn.nextInt();
		if(i >= 1 && i <= 12) {
			i = i/3;
			if(i == 1) {
				System.out.println("봄 입니다. ");
			}
			else if(i == 2) {
				System.out.println("여름 입니다. ");
			}
			else if(i == 3) {
				System.out.println("가을 입니다. ");
			}
			else{
				System.out.println("겨울 입니다. ");
			}
		}
		else {
			System.out.println("잘못 입력하였습니다. ");
		}
	}
}
