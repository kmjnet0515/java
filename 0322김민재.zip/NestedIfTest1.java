/*
 * 작성일 : 2024년 3월 22일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 내포된 if문 실습. 
 * 		  하나의 정수를 입력 받아 음수인지 확인하는 프로그램. 
 * 		  점수는 0~100점 사이 입니다. 
 * 		  점수 범위를 벗어나면 "잘못된 점수입니다. 출력하시오.
 * 
 * 문제분석 : 입력받은 점수가 0~100 사이인가? 
 * 			점수가 0~100 사이가 이니면? 
 * 			90점 이상이면 A학점 
 * 			80점 이상이면 B학점 
 * 			70점 이상이면 C학점 
 * 			60점 이상이면 D학점 
 * 			60점 이상이면 F학점 
 * 			점수는 정수로 입력받는다. 
 * 알고리즘 : 
 * 1. 점수(정수)를 입력받는다. 
 * 2. if 점수의 범위가 0~100 사이인가? 
 * 	2.1 A
 * 	2.2 B
 * 	2.3 C
 * 	2.4 D
 * 	2.5 F
 * 3. else 아닌가? 
 *	3.1 "잘못된 점수입니다" 출력 
 */
import java.util.Scanner;
public class NestedIfTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		System.out.print("수를 입력하세요. : ");
		int num = stdIn.nextInt();
		if(num >= 0 && num <= 100) {
			if(num >= 90) {
				System.out.println("A학점입니다.");
			}
			else if(num >= 80) {
				System.out.println("B학점입니다.");
			}
			else if(num >= 70) {
				System.out.println("C학점입니다.");
			}
			else if(num >= 60) {
				System.out.println("D학점입니다.");
			}
			else{
				System.out.println("F학점입니다.");
			}
		}
		else {
			System.out.println("잘못된 점수입니다");
		}
	}

}
/*
if(num1 % 2 == 0 && num2 % 2 == 0) 






*/