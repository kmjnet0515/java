/*
 * 작성일 : 2024년 3월 26일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 
 * 두 정수를 입력받아 두 수가 모두 짝수이면 더한 결과를 출력하고 그렇지 않고 두 수중 하나라도 홀수이면 몇 번째 입력한 수를 짝수로 입력해야하는지 출력하시오.
 * 
 * [문제분석]
 * 		짝수는 2로 나눈 나머지가 0이다.
 * 		홀수는 2로 나눈 나머지가 1이다.(0이 아니다.)
 * 		둘 다 짝수일 때 => 더한 후 출
 * 		하나라도 홀수일 때 => 몇 번째 수를 짝수로 입력해야할지 출력
 * 		둘 다 홀수일 때 => 둘 다 짝수로 입력해야한다 출
 * [알고리즘]
 * 1. 나머지의 합이 0일때
 * 1.1 하나의 나머지가 0일 때
 * 1.1.1 합 출력
 * 1.2 아니면
 * 1.2.1 둘 다 짝수로 입력되어야한다 출
 * 2. 아니면
 * 2.1 하나의 나머지가 0일 때
 * 2.1.1 다른 하나가 짝수로 입력되어야한다 출력
 * 2.2 아니면
 * 2.2.1 짝수로 입력되어야한다 출
 */
import java.util.Scanner;
public class SelectiveTest2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner stdIn = new Scanner(System.in);
		for(int i = 0; i < 1; i++) {
			System.out.println("두 수를 입력하세요.");
			int a = stdIn.nextInt();
			int b = stdIn.nextInt();
			if((a+b) % 2 == 0) {
				if(a % 2 == 0) {
					System.out.println("두 수의 합은 : " + (a + b));
				}
				else {
					System.out.println("두 수 모두 짝수로 입력되어야합니다.");
				}
			}
			else {
				System.out.println(((a%2 ==0)? "두 " :"첫 " )+ "번째 수가 짝수로 입력되어야합니다.");
			}
		}
		/*
		if(a%2 == 0) {
			if(b%2 ==0) {
				
			}
			else {
				
			}
		}
		else {
			if(b%2 ==0) {
							
			}
			else {
				
			}
		}
		*/
		int count = 3;
		int hap = 0;
		switch(count++) {
			case 3: hap+=count;
			System.out.println(count);
			case 4: hap+=count;
			System.out.println(count);
			case 5: hap+=count;
			System.out.println(count);
		}
		System.out.println(hap);
		boolean b2 = false;
		System.out.println((b2 = true));
	}

}
