class Box8{
	int width; // 접근 한정자가 없는 객체 변수 : 같은 패키지 내에서 접근 가능하다.
	int height; // 속성
	int depth;
	public Box8(int width, int height, int depth) {
		this.width = width;
		this.height = height;
		this.depth = depth;
	}
	int volume() { //메소드 
		return width * height * depth;
	}
}
public class Box8Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box8 mybox1 = new Box8(10,20,30);
		mybox1.width = 20; //width 접근 한정자가 없기 떄문에 값이 변경됨. 
		// 객체 이름으로 메소드 호출.  
		System.out.println(mybox1.volume());
	}

}
