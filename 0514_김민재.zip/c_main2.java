public class c_main2 {
	int count = 10; // 객체 변수 
	static int num = 20; // 클래스 변수
	
	// 메소드 선언. 
	public int sum(int x, int y) {
		return x + y;
	}
	static int mul(int x, int y) {
		return x * y;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int same = count; //일반 객체 변수를 static 메소드에서 사용 불가 
		
		//int same = sum(5,5); 객체 메소드를 static 메소드에서 호출 불가 
		c_main2 c = new c_main2();
		System.out.println(c.sum(c.count, c_main2.num));
		
		System.out.println(c_main2.mul(c.count, c_main2.num));
		
	}

}
