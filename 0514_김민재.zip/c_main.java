public class c_main {
	int count = 10; // 객체 변수 
	static int num = 20; // 클래스 변수
	
	// 메소드 선언. 
	public int sum(int x, int y) {
		return x + y;
	}
	static int mul(int x, int y) {
		return x * y;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		c_main c = new c_main();
		System.out.println(c.sum(c.count, c_main.num));
		
		System.out.println(c_main.mul(c.count, c_main.num));
		
	}

}
