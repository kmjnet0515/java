class Box9{
	private int width; // 접근 한정자가 없는 객체 변수 : 같은 패키지 내에서 접근 가능하다.
	private int height; // 속성
	private int depth;
	private int vol;
	public Box9(int width, int height, int depth) {
		this.width = width;
		this.height = height;
		this.depth = depth;
		volume();
	}
	private void volume() { //메소드 
		vol = width * height * depth;
	}
	public int getVolume() {
		return vol;
	}
}
public class Box9Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box9 mybox1 = new Box9(10,20,30);
		//mybox1.width = 20; 접근한정자가 private 이므로 값 변경 불가 
		// 객체 이름으로 메소드 호출.  
		//System.out.println(mybox1.volume());
		System.out.println(mybox1.getVolume());
	}

}
