/*
 * 작성일 : 2024 5월 3일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 클래스 모음 
 */
class PlusMinus {
	public int Add(int num1, int num2) {
		return num1 + num2;
	}
	public int Sub(int num1, int num2) {
		return num1 - num2;
	}
}

class MultiDiv extends PlusMinus{
	public int Mul(int num1, int num2) {
		return num1 * num2;
	}
	public int Div(int num1, int num2) {
		if(num2 == 0) {
			return 0;
		}
		return num1 / num2;
	}
}
public class Calculator {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PlusMinus cal = new PlusMinus();
		System.out.println(cal.Add(1,5));
		MultiDiv cal2 = new MultiDiv();
		System.out.println(cal2.Add(1, 7));
		System.out.println(cal2.Mul(2, 50));
		
	}
}
