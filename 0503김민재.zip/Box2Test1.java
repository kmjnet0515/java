class Box2{
	int width = 10;
	int height = 20;
	int depth = 30;
}
public class Box2Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int myInt1 = 100;
		int myInt2 = myInt1;
		System.out.println("첫 번째 값 : " + myInt1 + "두 번째 값 : " + myInt2);
		myInt1 = 200;
		System.out.println("첫 번째 값 : " + myInt1 + "두 번째 값 : " + myInt2);
		Box2 myBox1 = new Box2();
		Box2 myBox2 = new Box2();
		myBox1.width = 20;
		myBox2.depth = 123;
		System.out.println("myBox1.width : " + myBox1.width);
		System.out.println("myBox1.height : " + myBox1.height);
		System.out.println("myBox1.depth : " + myBox1.depth);
		
		System.out.println("myBox2.width : " + myBox2.width);
		System.out.println("myBox2.height : " + myBox2.height);
		System.out.println("myBox2.depth : " + myBox2.depth);
		
		Box2 myBox3 = myBox2;
		myBox2.width = 1000;
		myBox2.depth = 2000;
		System.out.println("myBox3.width : " + myBox3.width);
		System.out.println("myBox3.height : " + myBox3.height);
		System.out.println("myBox3.depth : " + myBox3.depth);
	}

}
