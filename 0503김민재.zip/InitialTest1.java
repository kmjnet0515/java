class Initial{
	// 멤버 변수. 묵시적 값 설정. 클래스 전체에서 사용. 
	// 클래스 내 메소드 밖에 선언. 
	int number;
	double rate;
	String name;
	int[] score;
	
	//메소드 선언(소문자로 시작) 
	public void aMethod() {
		int count = 0; //반드시 초기값을 지정해야한다. 초기값 없으면 오류 발생. 
		System.out.println("number : " + number);
		System.out.println("count : " + count);
	}
}
public class InitialTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int var1; //메인 메소드에서 사용하는 지역 변수.
		double var2; //초기값이 없다.
		
		//변수에 초기값이 없어 오류 발생함.
		//System.out.println("지역 변수 var1의 값은 : " + var1);
		//System.out.println("지역 변수 var2의 값은 : " + var2);
		
		Initial ob1 = new Initial();
		System.out.println("객체 변수 number의 값은 : " + ob1.number);
		System.out.println("객체 변수 rate의 값은 : " + ob1.rate);
		System.out.println("객체 변수 name의 값은 : " + ob1.name);
		System.out.println("객체 변수 score의 값은 : " + ob1.score);

		ob1.aMethod();
	}

}
