class Box3{
	int width, height, depth; //멤버 변수 - 객체 변수 
	long idNum; //멤버 변수 - 객체 변수 
	static long boxId = 0; //클래스 변수 -> 클래스 명으로 접근하기. 
	
	//생성자는 객체가 생성될 때 자동으로 수행(호출) 됨. 
	public Box3() {//생성자 메소드 - 클래ㅡ 명곽 ㅏㅌ은 메소드 
		idNum = ++boxId;
	}
}
public class Box3Test1 {

	public static void main(String[] args) {
		//객체 생성 
		Box3 myBox1 = new Box3();
		Box3 myBox2 = new Box3();
		Box3 myBox3 = new Box3();
		Box3 myBox4 = new Box3();
		
		System.out.println("myBox1의 id 번호 : " + myBox1.idNum); //1
		System.out.println("myBox2의 id 번호 : " + myBox2.idNum); //2
		System.out.println("myBox3의 id 번호 : " + myBox3.idNum); //3
		System.out.println("myBox4의 id 번호 : " + myBox4.boxId); //4
		//boxId는 클래스 변수이다.
		//오류는 아니지만 클래스 변수는 클래스 명으로 접근하라. 
		System.out.println("Box3의 클래스 변수 boxId : " + Box3.boxId);
		
		
	}

}
