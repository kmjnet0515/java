/*
 * 작성일 : 2024년 4월 5일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 정수를 입력받아서 그 수의 약수를 출력하시오.  
 * 문제분석 : 약수는 나누어떨어지는 수 

 * 알고리즘 : 
 * 1. number에 수를 입력받기.  
 * 2. number2가 1부터 number까지 1증가  
 * 3. number가 number2로 나누어떨어진다면
 * 3.1 number2 출력 
 */
import java.util.Scanner;
public class ForTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		int number = stdIn.nextInt();
		System.out.println(number + "의 약수");
		for(int number2 = 1; number2 <= number/2+1; number2++) {
			if(number % number2 == 0) {
				System.out.println(number2);
			}
		}
		if(number / 3 != 0)
			System.out.println(number);
	}
}
