/*
 * 작성일 : 2024년 4월 5일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 1부터 10까지 합을 출력하시오.
 * 
 */
import java.util.Scanner;
public class doWhileTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0,num = 1;
		do {
			sum += num++;
		}while(num <= 10);
		System.out.println(sum);
	}
}
