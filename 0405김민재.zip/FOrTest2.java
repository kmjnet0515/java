/*
 * 작성일 : 2024년 4월 5일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 알고싶은 단을 입력 받아 구구단을 출력하시오. 
 * 문제분석 : 입력받은 수를 1부터 9까지 반복하는 수와 곱해서 결과 출력 

 * 알고리즘 : 
 * 1. number에 수를 입력받기.  
 * 2. number2가 1부터 10보다 작을 때까지 1증가  
 * 3.1. number와 number2의 곱을 출력하기 
 * 4. 출력 
 */
import java.util.Scanner;
public class FOrTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdIn = new Scanner(System.in);
		int number = stdIn.nextInt();
		System.out.println(number +"단 출력");
		for(int number2 = 1; number2 < 10; number2++) 
			System.out.printf("%d x %d = %2d\n", number, number2, number * number2);
	}

}
