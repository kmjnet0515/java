/*
 * 작성일 : 2024년 4월 5일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 정수를 입력하여 * 출력하기
 * 
 * 
 */
import java.util.Scanner;
public class nestedLoopTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int a = scanner.nextInt();
		for(int i = 1; i<=a; i++) {
			for(int k = 1; k <= i; k++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("\n\n");
		for(int i = 1; i<=a; i++) {
			for(int k = a; k >= i; k--) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("\n\n");
		for(int i = 1; i<=a; i++) {
			for(int p = 1; p < i; p++) {
				System.out.print(" ");
			}
			for(int k = a; k >= i; k--) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("\n\n");
		for(int i = 1; i<=a; i++) {
			for(int p = a; p > i; p--) {
				System.out.print(" ");
			}
			for(int k = 1; k <= i; k++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("\n\n");
		for(int i = 1; i<=a; i++) {
			for(int p =a; p > i; p--) {
				System.out.print(" ");
			}
			for(int k = 1; k <= i*2-1; k++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("\n\n");
		for(int i = 1; i<=a; i++) {
			for(int p = 1; p < i; p++) {
				System.out.print(" ");
			}
			for(int k = (a - i)* 2 + 1; k >= 1; k--) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
