/*
 * 작성일 : 2024년 4월 5일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 1부터 10까지 합을 출력하시오.
 * 
 */
import java.util.Scanner;
public class doWhileTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int month;
		do {
			System.out.println("월을 입력하시오.");
			month = scanner.nextInt();
			switch(month) {
				case 3:
				case 4:
				case 5:
					System.out.println("봄입니다.");
					break;
				case 6:
				case 7:
				case 8:
					System.out.println("여름입니다.");
					break;
				case 9:
				case 10:
				case 11:
					System.out.println("가을입니다.");
					break;
				case 12:
				case 1:
				case 2:
					System.out.println("겨울입니다.");
					break;
				case 0:
					break;
				default:
					System.out.println("해당 월이 없습니다.");
			}
		}while(month != 0);
	}
}
