/*
 * 작성일 : 2024년 4월 5일 
 * 작성자 : 컴퓨터공학부 202395006 김민재 
 * 설명	: 전체구구단 
 * 문제분석 : 단은 2~9단까지  곱하는 수는 1~9까지 2단 출력하고 3단, 9단까지 반복한다. 
 * 
 * 알고리즘 
 * 1. 단은 2부터 9까지 반복
 * 1.1 곱하는 수는 1부터 9까지 반복 
 * 1.1.1 출
 * 
 * 
 */
import java.util.Scanner;
public class nestedLoopTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("for");
		for(int dan = 2; dan <= 9; dan++) {
			System.out.println(dan +"단 출력");
			for(int number = 1; number <= 9; number++) {
				System.out.printf("%d x %d = %d ", dan, number, dan * number);
			}
			System.out.println();
		}
		System.out.println("while");
		int dan = 2;
		while(dan <= 9) {
			System.out.println(dan +"단 출력");
			int number = 1;
			while(number <= 9) {
				System.out.printf("%d x %d = %d ", dan, number, dan * number);
				number++;
			}
			System.out.println();
			dan++;
		}
	}
}
